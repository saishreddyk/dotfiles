### [Alacritty](https://github.com/alacritty/alacritty)

#### Install

Download using the [GitHub `.zip` download](https://github.com/dracula/alacritty/archive/master.zip) option.

You just have to import `dracula.toml` in `~/.config/alacritty/alacritty.toml`.

```toml
import = ["/path/to/dracula.toml"]
```
